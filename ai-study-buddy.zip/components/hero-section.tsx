import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="py-16 md:py-24 lg:py-32 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
            Transform Your Study Materials with AI
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8">
            Convert documents, handwritten notes, and videos into interactive study tools powered by artificial
            intelligence.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="px-8">
              <Link href="/upload">
                Get Started <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/dashboard">View Dashboard</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Abstract background shapes */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-10 blur-3xl bg-gradient-to-r from-blue-500 to-purple-500 rounded-full -z-10" />
      <div className="absolute top-1/3 right-1/4 w-[400px] h-[400px] opacity-10 blur-3xl bg-gradient-to-r from-green-500 to-yellow-500 rounded-full -z-10" />
    </section>
  )
}
