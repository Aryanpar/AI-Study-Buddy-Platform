"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { FileUploader } from "@/components/file-uploader"
import { YouTubeInput } from "@/components/youtube-input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { FileText, ImageIcon, Youtube } from "lucide-react"

const formSchema = z.object({
  title: z.string().min(2, {
    message: "Title must be at least 2 characters.",
  }),
  fileType: z.enum(["document", "image", "youtube"]),
  file: z.any().optional(),
  youtubeUrl: z.string().url().optional(),
})

export function UploadForm() {
  const [isUploading, setIsUploading] = useState(false)
  const [filePreview, setFilePreview] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      fileType: "document",
      youtubeUrl: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsUploading(true)

    try {
      // Simulate upload process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      console.log(values)

      toast({
        title: "Upload successful!",
        description: "Your file has been uploaded and is being processed.",
      })

      // Redirect to appropriate page based on file type
      if (values.fileType === "document" || values.fileType === "image") {
        router.push("/summarize")
      } else if (values.fileType === "youtube") {
        router.push("/summarize")
      }
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your file. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const handleFileChange = (file: File | null) => {
    if (file) {
      form.setValue("file", file)

      // Create preview for images
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setFilePreview(e.target?.result as string)
        }
        reader.readAsDataURL(file)
      } else {
        setFilePreview(null)
      }
    } else {
      form.setValue("file", undefined)
      setFilePreview(null)
    }
  }

  return (
    <Card className="p-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Title</FormLabel>
                <FormControl>
                  <Input placeholder="Enter a title for your study material" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Tabs
            defaultValue="document"
            onValueChange={(value) => form.setValue("fileType", value as "document" | "image" | "youtube")}
            className="w-full"
          >
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="document" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>Document</span>
              </TabsTrigger>
              <TabsTrigger value="image" className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4" />
                <span>Image</span>
              </TabsTrigger>
              <TabsTrigger value="youtube" className="flex items-center gap-2">
                <Youtube className="h-4 w-4" />
                <span>YouTube</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="document">
              <FileUploader accept=".pdf,.doc,.docx,.txt" maxSize={10} onFileChange={handleFileChange} />
            </TabsContent>

            <TabsContent value="image">
              <FileUploader accept="image/*" maxSize={5} onFileChange={handleFileChange} preview={filePreview} />
            </TabsContent>

            <TabsContent value="youtube">
              <YouTubeInput onChange={(url) => form.setValue("youtubeUrl", url)} />
            </TabsContent>
          </Tabs>

          <Button type="submit" className="w-full" disabled={isUploading}>
            {isUploading ? "Uploading..." : "Upload and Process"}
          </Button>
        </form>
      </Form>
    </Card>
  )
}
