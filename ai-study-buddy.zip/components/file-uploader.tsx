"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, X, FileText, ImageIcon } from "lucide-react"
import Image from "next/image"
import { useToast } from "@/components/ui/use-toast"

interface FileUploaderProps {
  accept: string
  maxSize: number // in MB
  onFileChange: (file: File | null) => void
  preview?: string | null
}

export function FileUploader({ accept, maxSize, onFileChange, preview }: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [progress, setProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handleFile = (file: File) => {
    // Check file type
    const fileType = file.type
    const acceptedTypes = accept.split(",").map((type) => type.trim())

    const isAccepted = acceptedTypes.some((type) => {
      if (type.includes("*")) {
        return fileType.startsWith(type.replace("*", ""))
      }
      return fileType === type
    })

    if (!isAccepted) {
      toast({
        title: "Invalid file type",
        description: `Please upload a file with one of these formats: ${accept}`,
        variant: "destructive",
      })
      return
    }

    // Check file size
    if (file.size > maxSize * 1024 * 1024) {
      toast({
        title: "File too large",
        description: `Maximum file size is ${maxSize}MB`,
        variant: "destructive",
      })
      return
    }

    setFile(file)
    onFileChange(file)

    // Simulate upload progress
    simulateUpload()
  }

  const simulateUpload = () => {
    setIsUploading(true)
    setProgress(0)

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          return 100
        }
        return prev + 10
      })
    }, 200)
  }

  const removeFile = () => {
    setFile(null)
    onFileChange(null)
    setProgress(0)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const getFileIcon = () => {
    if (file?.type.startsWith("image/")) {
      return <ImageIcon className="h-12 w-12 text-primary" />
    }
    return <FileText className="h-12 w-12 text-primary" />
  }

  return (
    <div className="space-y-4">
      {!file ? (
        <Card
          className={`border-2 border-dashed p-6 text-center ${
            isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/20"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center justify-center space-y-4 py-4">
            <Upload className="h-12 w-12 text-muted-foreground" />
            <div className="space-y-2">
              <h3 className="text-lg font-medium">Drag & drop your file here</h3>
              <p className="text-sm text-muted-foreground">or click to browse (max {maxSize}MB)</p>
            </div>
            <Button variant="secondary" onClick={() => fileInputRef.current?.click()}>
              Select File
            </Button>
            <input ref={fileInputRef} type="file" accept={accept} onChange={handleFileInput} className="hidden" />
          </div>
        </Card>
      ) : (
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {preview ? (
                <div className="relative h-16 w-16 overflow-hidden rounded-md">
                  <Image src={preview || "/placeholder.svg"} alt="File preview" fill className="object-cover" />
                </div>
              ) : (
                getFileIcon()
              )}
              <div>
                <p className="font-medium">{file.name}</p>
                <p className="text-sm text-muted-foreground">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={removeFile} disabled={isUploading}>
              <X className="h-5 w-5" />
            </Button>
          </div>

          {isUploading && (
            <div className="mt-4 space-y-2">
              <Progress value={progress} />
              <p className="text-xs text-right text-muted-foreground">{progress}%</p>
            </div>
          )}
        </Card>
      )}
    </div>
  )
}
