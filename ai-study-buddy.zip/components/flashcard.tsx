"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { RotateCw, Trash } from "lucide-react"

interface FlashcardProps {
  card: {
    id: string
    question: string
    answer: string
  }
  mode: "study" | "edit"
  onUpdate?: (id: string, field: "question" | "answer", value: string) => void
  onDelete?: (id: string) => void
}

export function Flashcard({ card, mode, onUpdate, onDelete }: FlashcardProps) {
  const [flipped, setFlipped] = useState(false)

  const handleFlip = () => {
    if (mode === "study") {
      setFlipped(!flipped)
    }
  }

  if (mode === "edit") {
    return (
      <Card className="h-[200px] overflow-hidden">
        <CardContent className="p-4 h-full flex flex-col">
          <div className="flex justify-between mb-2">
            <span className="text-xs font-medium text-muted-foreground">Question</span>
            {onDelete && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-destructive"
                onClick={() => onDelete(card.id)}
              >
                <Trash className="h-4 w-4" />
              </Button>
            )}
          </div>
          <Textarea
            value={card.question}
            onChange={(e) => onUpdate?.(card.id, "question", e.target.value)}
            className="flex-grow resize-none mb-2 text-sm"
            placeholder="Enter question..."
          />
          <span className="text-xs font-medium text-muted-foreground mb-1">Answer</span>
          <Textarea
            value={card.answer}
            onChange={(e) => onUpdate?.(card.id, "answer", e.target.value)}
            className="flex-grow resize-none text-sm"
            placeholder="Enter answer..."
          />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card
      className={`h-[200px] cursor-pointer relative transition-all duration-500 ${flipped ? "bg-muted/30" : ""}`}
      onClick={handleFlip}
    >
      <div className="absolute top-2 right-2">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 opacity-50 hover:opacity-100"
          onClick={(e) => {
            e.stopPropagation()
            handleFlip()
          }}
        >
          <RotateCw className="h-4 w-4" />
        </Button>
      </div>

      <CardContent className="p-6 h-full flex items-center justify-center">
        <div className="text-center">
          {flipped ? (
            <>
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Answer</div>
              <p>{card.answer}</p>
            </>
          ) : (
            <>
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Question</div>
              <p className="font-medium">{card.question}</p>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
