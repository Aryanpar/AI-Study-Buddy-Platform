"use client"

import { BookOpen, FileText, FlaskConical, Home, Lightbulb, Network, Settings, Upload, User } from "lucide-react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar"

export function AppSidebar() {
  const pathname = usePathname()

  const menuItems = [
    { title: "Home", icon: Home, path: "/" },
    { title: "Upload", icon: Upload, path: "/upload" },
    { title: "Summaries", icon: FileText, path: "/summarize" },
    { title: "Flashcards", icon: BookOpen, path: "/flashcards" },
    { title: "Quizzes", icon: FlaskConical, path: "/quiz" },
    { title: "Mind Maps", icon: Network, path: "/mindmap" },
    { title: "Dashboard", icon: User, path: "/dashboard" },
    { title: "Settings", icon: Settings, path: "/settings" },
  ]

  return (
    <>
      <Sidebar>
        <SidebarHeader className="flex items-center px-4 py-2">
          <div className="flex items-center gap-2">
            <Lightbulb className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Study Buddy</span>
          </div>
          <div className="ml-auto md:hidden">
            <SidebarTrigger />
          </div>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {menuItems.map((item) => (
              <SidebarMenuItem key={item.path}>
                <SidebarMenuButton asChild isActive={pathname === item.path} tooltip={item.title}>
                  <Link href={item.path}>
                    <item.icon />
                    <span>{item.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="p-4">
          <div className="text-xs text-muted-foreground text-center">AI Study Buddy v1.0</div>
        </SidebarFooter>
      </Sidebar>
    </>
  )
}
