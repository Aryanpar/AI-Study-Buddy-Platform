"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Download, Copy, Wand2 } from "lucide-react"

// Mock data for demonstration
const mockDocument = {
  title: "Introduction to Quantum Computing",
  content: `Quantum computing is an area of computing focused on developing computer technology based on the principles of quantum theory. Quantum computers use quantum bits or qubits, which can exist in multiple states simultaneously, unlike classical bits that can only be in one of two states (0 or 1). This property, known as superposition, along with entanglement, allows quantum computers to perform certain calculations much faster than classical computers.

The field of quantum computing began in the early 1980s when physicist Richard Feynman proposed a quantum model of computation. Quantum computers have the potential to solve certain problems much more quickly than any classical computer using the best currently known algorithms, like integer factorization using Shor's algorithm or the simulation of quantum many-body systems.

However, current quantum computers are very susceptible to errors due to decoherence, noise, manufacturing defects, and imperfect control signals. Error correction is therefore essential for practical quantum computing, but it's challenging due to the no-cloning theorem, which states that it's impossible to create an identical copy of an arbitrary unknown quantum state.

Despite these challenges, quantum computing has seen significant advancements in recent years, with companies like IBM, Google, and Microsoft investing heavily in the technology. In 2019, Google claimed to have achieved quantum supremacy, performing a calculation that would be practically impossible for a classical computer.

The potential applications of quantum computing are vast, including cryptography, optimization problems, drug discovery, and material science. As the technology continues to develop, it's expected to revolutionize many fields and solve problems that are currently intractable.`,
}

export function SummaryGenerator() {
  const [summaryLength, setSummaryLength] = useState<"short" | "medium" | "detailed">("medium")
  const [language, setLanguage] = useState("english")
  const [isGenerating, setIsGenerating] = useState(false)
  const [summary, setSummary] = useState("")
  const { toast } = useToast()

  const generateSummary = async () => {
    setIsGenerating(true)
    setSummary("")

    try {
      // In a real application, we would use the actual document content
      // For demo purposes, we're using the mock data

      let promptLength = ""
      if (summaryLength === "short") {
        promptLength = "Create a very concise summary in 2-3 sentences"
      } else if (summaryLength === "medium") {
        promptLength = "Create a moderate length summary in about 5-7 sentences"
      } else {
        promptLength = "Create a detailed summary covering all key points"
      }

      let languagePrompt = ""
      if (language !== "english") {
        languagePrompt = ` Translate the summary to ${language}.`
      }

      const prompt = `${promptLength} of the following text:
      
      ${mockDocument.content}
      ${languagePrompt}`

      // For demo purposes, we'll simulate the AI response
      // In a real app, you would use:
      /*
      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: prompt,
      });
      setSummary(text);
      */

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulated responses based on length
      if (summaryLength === "short") {
        setSummary(
          "Quantum computing leverages quantum bits (qubits) that can exist in multiple states simultaneously, enabling faster computation for specific problems than classical computers. Despite challenges like decoherence and errors, companies like IBM and Google have made significant advancements, with potential applications in cryptography, optimization, drug discovery, and material science.",
        )
      } else if (summaryLength === "medium") {
        setSummary(
          "Quantum computing is based on quantum theory principles, using qubits that can exist in multiple states simultaneously through superposition. Unlike classical bits limited to 0 or 1 states, this property along with entanglement allows quantum computers to solve certain problems much faster. The field began in the 1980s with Richard Feynman's quantum computation model and has potential applications in integer factorization, quantum system simulation, cryptography, optimization, drug discovery, and material science. Current quantum computers face challenges from decoherence, noise, and manufacturing defects, requiring error correction that's complicated by the no-cloning theorem. Despite these obstacles, companies like IBM, Google, and Microsoft have invested heavily, with Google claiming quantum supremacy in 2019 by performing calculations practically impossible for classical computers.",
        )
      } else {
        setSummary(
          "Quantum computing represents a revolutionary approach to computation based on the principles of quantum theory. At its core, quantum computers utilize quantum bits or qubits, which differ fundamentally from classical bits. While classical bits can only exist in one of two states (0 or 1), qubits can exist in multiple states simultaneously due to a quantum property called superposition. This property, combined with another quantum phenomenon called entanglement, provides quantum computers with unprecedented computational capabilities for specific problems.\n\nThe conceptual foundation of quantum computing was established in the early 1980s when the renowned physicist Richard Feynman proposed a quantum model of computation. The theoretical potential of quantum computers is remarkable – they can perform certain calculations exponentially faster than the most powerful classical computers using current algorithms. Notable examples include integer factorization using Shor's algorithm (which has significant implications for cryptography) and the simulation of quantum many-body systems (crucial for understanding quantum physics and chemistry).\n\nHowever, the practical implementation of quantum computing faces substantial challenges. Current quantum computers are highly susceptible to errors arising from various sources: decoherence (the loss of quantum information due to interaction with the environment), noise, manufacturing defects in quantum hardware, and imperfect control signals. Error correction is therefore essential for practical quantum computing but presents unique challenges due to the no-cloning theorem – a fundamental principle of quantum mechanics stating that it's impossible to create an identical copy of an arbitrary unknown quantum state.\n\nDespite these formidable challenges, the field has witnessed significant advancements in recent years. Technology giants including IBM, Google, and Microsoft have invested heavily in quantum computing research and development. A notable milestone occurred in 2019 when Google claimed to have achieved quantum supremacy – demonstrating a quantum computer performing a specific calculation that would be practically impossible for even the most powerful classical supercomputers.\n\nThe potential applications of quantum computing span numerous fields. Beyond cryptography and the breaking of current encryption standards, quantum computers could revolutionize optimization problems (finding the best solution among many possibilities), accelerate drug discovery by simulating molecular interactions with unprecedented accuracy, and advance material science by modeling complex quantum systems. As the technology continues to mature, quantum computing is expected to transform many scientific and industrial domains by solving problems that remain intractable with classical computing approaches.",
        )
      }

      toast({
        title: "Summary generated",
        description: "Your AI summary has been created successfully.",
      })
    } catch (error) {
      console.error("Error generating summary:", error)
      toast({
        title: "Generation failed",
        description: "There was an error generating your summary. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(summary)
    toast({
      title: "Copied to clipboard",
      description: "Summary has been copied to your clipboard.",
    })
  }

  const downloadSummary = () => {
    const element = document.createElement("a")
    const file = new Blob([summary], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `${mockDocument.title} - ${summaryLength} summary.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{mockDocument.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Summary Length</label>
                <Select
                  value={summaryLength}
                  onValueChange={(value) => setSummaryLength(value as "short" | "medium" | "detailed")}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select length" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Short (2-3 sentences)</SelectItem>
                    <SelectItem value="medium">Medium (5-7 sentences)</SelectItem>
                    <SelectItem value="detailed">Detailed (comprehensive)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Language</label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Spanish</SelectItem>
                    <SelectItem value="french">French</SelectItem>
                    <SelectItem value="german">German</SelectItem>
                    <SelectItem value="chinese">Chinese</SelectItem>
                    <SelectItem value="japanese">Japanese</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button onClick={generateSummary} disabled={isGenerating} className="w-full">
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-4 w-4" />
                  Generate Summary
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {summary && (
        <Card>
          <CardHeader>
            <CardTitle>Generated Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea value={summary} readOnly className="min-h-[200px]" />
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button variant="outline" onClick={copyToClipboard}>
              <Copy className="mr-2 h-4 w-4" />
              Copy
            </Button>
            <Button variant="outline" onClick={downloadSummary}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
