"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Play, Wand2 } from "lucide-react"

// Mock data for demonstration
const mockDocument = {
  title: "Introduction to Quantum Computing",
}

// Mock quiz questions
const mockQuestions = [
  {
    id: "1",
    question: "What is the fundamental unit of quantum information?",
    options: [
      { id: "a", text: "Bit" },
      { id: "b", text: "Qubit" },
      { id: "c", text: "Byte" },
      { id: "d", text: "Quantum Byte" },
    ],
    correctAnswer: "b",
  },
  {
    id: "2",
    question: "Which physicist proposed the quantum model of computation in the early 1980s?",
    options: [
      { id: "a", text: "Albert Einstein" },
      { id: "b", text: "Niels Bohr" },
      { id: "c", text: "Richard Feynman" },
      { id: "d", text: "Stephen Hawking" },
    ],
    correctAnswer: "c",
  },
  {
    id: "3",
    question: "What quantum property allows qubits to exist in multiple states simultaneously?",
    options: [
      { id: "a", text: "Entanglement" },
      { id: "b", text: "Superposition" },
      { id: "c", text: "Quantum tunneling" },
      { id: "d", text: "Wave-particle duality" },
    ],
    correctAnswer: "b",
  },
  {
    id: "4",
    question: "What is quantum supremacy?",
    options: [
      { id: "a", text: "When quantum computers can solve any problem" },
      { id: "b", text: "When quantum computers become self-aware" },
      { id: "c", text: "When quantum computers solve a problem impossible for classical computers" },
      { id: "d", text: "When quantum computers can communicate faster than light" },
    ],
    correctAnswer: "c",
  },
  {
    id: "5",
    question: "Which of these is NOT a major challenge in quantum computing?",
    options: [
      { id: "a", text: "Decoherence" },
      { id: "b", text: "Error correction" },
      { id: "c", text: "Manufacturing defects" },
      { id: "d", text: "Overheating due to quantum friction" },
    ],
    correctAnswer: "d",
  },
]

type QuizMode = "generate" | "edit" | "take" | "results"

export function QuizGenerator() {
  const [mode, setMode] = useState<QuizMode>("generate");
  const [isGenerating, setIsGenerating] = useState(false);
  const [questions, setQuestions] = useState<typeof mockQuestions>([]);
  const [numQuestions, setNumQuestions] = useState("5");
  const [difficulty, setDifficulty] = useState("medium");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const { toast } = useToast();

  const generateQuiz = async () => {
    setIsGenerating(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // In a real app, we would generate quiz questions using AI
      setQuestions(mockQuestions.slice(0, Number.parseInt(numQuestions)));
      setMode("edit");
      
      toast({
        title: "Quiz generated",
        description: `Created ${numQuestions} questions for your quiz.`,
      });
    } catch (error) {
      console.error("Error generating quiz:", error);
      toast({
        title: "Generation failed",
        description: "There was an error generating your quiz. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const startQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setMode("take");
  };

  const handleAnswer = (questionId: string, answerId: string) => {
    setAnswers({
      ...answers,
      [questionId]: answerId
    });
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Calculate score
      let correct = 0;
      questions.forEach(q => {
        if (answers[q.id] === q.correctAnswer) {
          correct++;
        }
      });
      
      setScore({
        correct,
        total: questions.length
      });
      
      setMode("results");
    }
  };

  const updateQuestion = (questionId: string, field: string, value: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId ? { ...q, [field]: value } : q
    ));
  };

  const updateOption = (questionId: string, optionId: string, value: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId ? {
        ...q,
        options: q.options.map(o => 
          o.id === optionId ? { ...o, text: value } : o
        )
      } : q
    ));
  };

  const setCorrectAnswer = (questionId: string, optionId: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId ? { ...q, correctAnswer: optionId } : q
    ));
  };

  const renderGenerateMode = () => (
    <Card>
      <CardHeader>
        <CardTitle>{mockDocument.title} - Create Quiz</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="num-questions">Number of Questions</Label>
              <Select value={numQuestions} onValueChange={setNumQuestions}>
                <SelectTrigger id="num-questions">
                  <SelectValue placeholder="Select number of questions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 Questions</SelectItem>
                  <SelectItem value="5">5 Questions</SelectItem>
                  <SelectItem value="10">10 Questions</SelectItem>
                  <SelectItem value="15">15 Questions</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="difficulty">Difficulty Level</Label>
              <Select value={difficulty} onValueChange={setDifficulty}>
                <SelectTrigger id="difficulty">
                  <SelectValue placeholder="Select difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button 
            onClick={generateQuiz} 
            disabled={isGenerating}
            className="w-full"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Wand2 className="mr-2 h-4 w-4" />
                Generate Quiz
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderEditMode = () => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{mockDocument.title} - Edit Quiz</CardTitle>
        <Button onClick={startQuiz}>
          <Play className="mr-2 h-4 w-4" />
          Start Quiz
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          {questions.map((q, index) => (
            <div key={q.id} className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="font-medium text-lg">Q{index + 1}.</span>
                <Input 
                  value={q.question}
                  onChange={(e) => updateQuestion(q.id, "question", e.target.value)}
                  className="flex-1"
                />
              </div>
              
              <div className="pl-6 space-y-2">
                {q.options.map((option) => (
                  <div key={option.id} className="flex items-center gap-2">
                    <RadioGroup 
                      value={q.correctAnswer} \
