"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Download, Loader2, Plus, Printer, Wand2 } from "lucide-react"
import { Flashcard } from "@/components/flashcard"

// Mock data for demonstration
const mockDocument = {
  title: "Introduction to Quantum Computing",
}

// Mock flashcards
const mockFlashcards = [
  {
    id: "1",
    question: "What is a qubit?",
    answer:
      "A quantum bit (qubit) is the basic unit of quantum information that can exist in multiple states simultaneously, unlike classical bits that can only be in one of two states (0 or 1).",
  },
  {
    id: "2",
    question: "Who proposed the quantum model of computation?",
    answer: "Physicist Richard Feynman proposed a quantum model of computation in the early 1980s.",
  },
  {
    id: "3",
    question: "What is quantum superposition?",
    answer:
      "Superposition is a quantum property that allows qubits to exist in multiple states simultaneously, enabling quantum computers to perform certain calculations much faster than classical computers.",
  },
  {
    id: "4",
    question: "What is quantum entanglement?",
    answer:
      "Quantum entanglement is a physical phenomenon where pairs or groups of particles interact in ways such that the quantum state of each particle cannot be described independently of the others, regardless of the distance separating them.",
  },
  {
    id: "5",
    question: "What is quantum supremacy?",
    answer:
      "Quantum supremacy refers to the demonstration of a quantum computer solving a problem that would be practically impossible for a classical computer to solve in a reasonable amount of time.",
  },
  {
    id: "6",
    question: "What are some potential applications of quantum computing?",
    answer: "Potential applications include cryptography, optimization problems, drug discovery, and material science.",
  },
]

export function FlashcardGenerator() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [flashcards, setFlashcards] = useState<typeof mockFlashcards>([])
  const [viewMode, setViewMode] = useState<"study" | "edit">("study")
  const { toast } = useToast()

  const generateFlashcards = async () => {
    setIsGenerating(true)

    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // In a real app, we would generate flashcards using AI
      setFlashcards(mockFlashcards)

      toast({
        title: "Flashcards generated",
        description: `Created ${mockFlashcards.length} flashcards from your document.`,
      })
    } catch (error) {
      console.error("Error generating flashcards:", error)
      toast({
        title: "Generation failed",
        description: "There was an error generating your flashcards. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const addNewFlashcard = () => {
    const newId = (flashcards.length + 1).toString()
    setFlashcards([
      ...flashcards,
      {
        id: newId,
        question: "New Question",
        answer: "New Answer",
      },
    ])
  }

  const updateFlashcard = (id: string, field: "question" | "answer", value: string) => {
    setFlashcards(flashcards.map((card) => (card.id === id ? { ...card, [field]: value } : card)))
  }

  const deleteFlashcard = (id: string) => {
    setFlashcards(flashcards.filter((card) => card.id !== id))
  }

  const printFlashcards = () => {
    window.print()
  }

  const downloadFlashcards = () => {
    const content = flashcards.map((card) => `Question: ${card.question}\nAnswer: ${card.answer}\n\n`).join("")

    const element = document.createElement("a")
    const file = new Blob([content], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `${mockDocument.title} - Flashcards.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{mockDocument.title}</CardTitle>
        </CardHeader>
        <CardContent>
          {flashcards.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-8 border rounded-md border-dashed">
              <p className="text-muted-foreground mb-4">
                No flashcards generated yet. Click the button below to create flashcards from your document.
              </p>
              <Button onClick={generateFlashcards} disabled={isGenerating}>
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generate Flashcards
                  </>
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "study" | "edit")}>
                  <TabsList>
                    <TabsTrigger value="study">Study Mode</TabsTrigger>
                    <TabsTrigger value="edit">Edit Mode</TabsTrigger>
                  </TabsList>
                </Tabs>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={printFlashcards}>
                    <Printer className="h-4 w-4 mr-1" />
                    Print
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadFlashcards}>
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {flashcards.map((card) => (
                  <Flashcard
                    key={card.id}
                    card={card}
                    mode={viewMode}
                    onUpdate={updateFlashcard}
                    onDelete={deleteFlashcard}
                  />
                ))}

                {viewMode === "edit" && (
                  <Button
                    variant="outline"
                    className="h-[200px] border-dashed flex flex-col gap-2"
                    onClick={addNewFlashcard}
                  >
                    <Plus className="h-6 w-6" />
                    Add New Flashcard
                  </Button>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
