"use client"

import type React from "react"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Youtube, X } from "lucide-react"

interface YouTubeInputProps {
  onChange: (url: string) => void
}

export function YouTubeInput({ onChange }: YouTubeInputProps) {
  const [url, setUrl] = useState("")
  const [isValid, setIsValid] = useState(false)
  const [videoId, setVideoId] = useState<string | null>(null)
  const { toast } = useToast()

  const validateYouTubeUrl = (url: string) => {
    // Regular expression to extract YouTube video ID
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/
    const match = url.match(regExp)

    if (match && match[2].length === 11) {
      setIsValid(true)
      setVideoId(match[2])
      onChange(url)
      return true
    } else {
      setIsValid(false)
      setVideoId(null)
      return false
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!url) {
      toast({
        title: "URL required",
        description: "Please enter a YouTube URL",
        variant: "destructive",
      })
      return
    }

    if (!validateYouTubeUrl(url)) {
      toast({
        title: "Invalid YouTube URL",
        description: "Please enter a valid YouTube video URL",
        variant: "destructive",
      })
    }
  }

  const clearUrl = () => {
    setUrl("")
    setIsValid(false)
    setVideoId(null)
    onChange("")
  }

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type="url"
            placeholder="Paste YouTube URL here"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="pr-10"
          />
          {url && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-0 top-0 h-full"
              onClick={clearUrl}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        <Button type="submit">Validate</Button>
      </form>

      {videoId && (
        <Card className="overflow-hidden">
          <div className="aspect-video">
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${videoId}`}
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        </Card>
      )}

      {!videoId && url && (
        <div className="flex items-center justify-center p-8 border rounded-md border-dashed">
          <div className="flex flex-col items-center text-muted-foreground">
            <Youtube className="h-12 w-12 mb-2" />
            <p>Enter a valid YouTube URL to preview</p>
          </div>
        </div>
      )}
    </div>
  )
}
