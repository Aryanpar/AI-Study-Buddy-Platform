import { PageHeader } from "@/components/page-header"
import { QuizGenerator } from "@/components/quiz-generator"

export default function QuizPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader title="Quiz Generator" description="Create multiple-choice quizzes based on your uploaded content." />

      <div className="max-w-4xl mx-auto mt-8">
        <QuizGenerator />
      </div>
    </div>
  )
}
