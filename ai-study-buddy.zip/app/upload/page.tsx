import { UploadForm } from "@/components/upload-form"
import { PageHeader } from "@/components/page-header"

export default function UploadPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader
        title="Upload Study Materials"
        description="Upload PDFs, images of handwritten notes, or YouTube links to transform them into study materials."
      />

      <div className="max-w-3xl mx-auto mt-8">
        <UploadForm />
      </div>
    </div>
  )
}
