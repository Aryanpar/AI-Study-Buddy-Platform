import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, BookOpen, FileText, FlaskConical, Lightbulb, Upload } from "lucide-react"
import Link from "next/link"
import { FeatureCard } from "@/components/feature-card"
import { HeroSection } from "@/components/hero-section"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <HeroSection />

      <section className="my-16">
        <h2 className="text-3xl font-bold text-center mb-12">Transform Your Study Materials</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard
            icon={<Upload className="h-10 w-10 text-blue-500" />}
            title="Easy Upload"
            description="Upload PDFs, images of handwritten notes, or YouTube links with simple validation and preview."
            link="/upload"
          />

          <FeatureCard
            icon={<FileText className="h-10 w-10 text-green-500" />}
            title="AI Summaries"
            description="Generate concise summaries at different detail levels with optional language translation."
            link="/summarize"
          />

          <FeatureCard
            icon={<BookOpen className="h-10 w-10 text-purple-500" />}
            title="Flashcards"
            description="Automatically create Q&A flashcards from your content that you can export or study online."
            link="/flashcards"
          />

          <FeatureCard
            icon={<FlaskConical className="h-10 w-10 text-orange-500" />}
            title="Quiz Generator"
            description="Create multiple-choice quizzes based on your documents with score tracking."
            link="/quiz"
          />

          <FeatureCard
            icon={<Lightbulb className="h-10 w-10 text-yellow-500" />}
            title="Mind Maps"
            description="Visualize content hierarchies with interactive mind maps to better understand relationships."
            link="/mindmap"
          />

          <Card className="flex flex-col justify-between border-dashed border-2 bg-muted/50">
            <CardHeader>
              <CardTitle className="text-xl">Ready to start?</CardTitle>
              <CardDescription>Begin by uploading your first document or video</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/upload">
                  Get Started <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </section>
    </div>
  )
}
