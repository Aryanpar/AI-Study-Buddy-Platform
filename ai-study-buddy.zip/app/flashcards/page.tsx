import { PageHeader } from "@/components/page-header"
import { FlashcardGenerator } from "@/components/flashcard-generator"

export default function FlashcardsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader
        title="Flashcard Generator"
        description="Automatically create study flashcards from your uploaded content."
      />

      <div className="max-w-4xl mx-auto mt-8">
        <FlashcardGenerator />
      </div>
    </div>
  )
}
