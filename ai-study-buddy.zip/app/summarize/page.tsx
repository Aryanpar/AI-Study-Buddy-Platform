import { PageHeader } from "@/components/page-header"
import { SummaryGenerator } from "@/components/summary-generator"

export default function SummarizePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <PageHeader
        title="AI Summary Generator"
        description="Generate concise summaries of your uploaded content at different detail levels."
      />

      <div className="max-w-4xl mx-auto mt-8">
        <SummaryGenerator />
      </div>
    </div>
  )
}
